import subprocess
import os

def test_validation_logic():
    """Test that the COBOL EFT validator correctly calculates totals and checksums."""
    # 1. Compile
    compile_cmd = ["cobc", "-x", "-o", "validator", "/app/validate.cbl"]
    try:
        subprocess.run(compile_cmd, check=True, capture_output=True)
    except subprocess.CalledProcessError as e:
        assert False, f"Compilation failed: {e.stderr.decode()}"

    def run_on_content(content):
        with open("eft_input.dat", "w") as f:
            f.write(content)
        result = subprocess.run(["./validator"], capture_output=True, text=True)
        return result.stdout.strip()

    # Case 1: Valid
    valid = "H2023123100001\nD00000100001234567890120000000045\nT0000000001000000001\n"
    assert "VALID" in run_on_content(valid)

    # Case 2: Count Mismatch
    invalid_count = "H2023123100001\nD00000100001234567890120000000045\nT0000000001000000002\n"
    assert "COUNT_MISMATCH" in run_on_content(invalid_count)

def test_cobol_formatting():
    """Verify that the COBOL source follows strict fixed-format rules (Area A/B)."""
    source_path = "/app/validate.cbl"
    assert os.path.exists(source_path), "COBOL source file not found"

    with open(source_path, "r") as f:
        lines = f.readlines()

    for i, line in enumerate(lines, 1):
        # Skip empty lines
        if not line.strip():
            continue
            
        # 1. Check Indicator Column (Column 7 / index 6)
        if len(line) > 6:
            indicator = line[6]
            assert indicator in (' ', '*', '-', '/'), f"Line {i}: Invalid indicator '{indicator}' in column 7. Expected space or '*'."
            if indicator == '*':
                continue

        # 2. Check Area A/B
        line_content = line[7:].upper().lstrip()
        if not line_content:
            continue

        raw_content = line[7:]
        leading_spaces = len(raw_content) - len(raw_content.lstrip())
        
        is_area_a_keyword = any(line_content.startswith(k) for k in [
            "IDENTIFICATION DIVISION", "ENVIRONMENT DIVISION", "DATA DIVISION", "PROCEDURE DIVISION",
            "FILE SECTION", "WORKING-STORAGE SECTION", "INPUT-OUTPUT SECTION", "LINKAGE SECTION",
            "01 ", "77 ", "FD ", "SELECT "
        ])
        
        is_label = line_content.strip().endswith('.') and leading_spaces == 0

        if is_area_a_keyword or is_label:
            assert leading_spaces == 0, f"Line {i}: '{line_content.split()[0]}' should start in Area A (column 8)."
        else:
            if any(line_content.startswith(k) for k in ["MOVE ", "ADD ", "READ ", "WRITE ", "OPEN ", "CLOSE ", "PERFORM ", "IF ", "STOP ", "DISPLAY ", "END-", "COMPUTE ", "SET ", "GO "]):
                assert leading_spaces >= 4, f"Line {i}: Statement '{line_content.split()[0]}' should start in Area B (column 12 or later)."
