       IDENTIFICATION DIVISION.
       PROGRAM-ID. EFT-VALIDATOR.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT EFT-FILE ASSIGN TO "eft_input.dat"
               ORGANIZATION IS LINE SEQUENTIAL.
       DATA DIVISION.
       FILE SECTION.
       FD EFT-FILE.
       01 EFT-REC.
           05 REC-TYPE         PIC X.
           05 REC-DATA         PIC X(79).

       WORKING-STORAGE SECTION.
       01 WS-EOF               PIC X VALUE 'N'.
       01 WS-DETAIL-COUNT      PIC 9(5) VALUE 0.
       01 WS-SUM-AMOUNT        PIC 9(13)V99 VALUE 0.
       
       01 DETAIL-REC.
           05 FILLER           PIC X.
           05 DET-AMOUNT       PIC 9(8)V99.
           05 DET-ACCOUNT      PIC X(12).
           05 DET-CHKSUM       PIC X(10).

       01 TRAILER-REC.
           05 FILLER           PIC X.
           05 TRL-TOTAL        PIC 9(13)V99.
           05 TRL-COUNT        PIC 9(5).

       PROCEDURE DIVISION.
           OPEN INPUT EFT-FILE.
           
           READ EFT-FILE AT END MOVE 'Y' TO WS-EOF.
           
           PERFORM UNTIL WS-EOF = 'Y'
               IF REC-TYPE = 'D'
      * BUG 1: Forgot to Parse detail record properly
      * BUG 2: Current code doesn't update running totals correctly
                   ADD 1 TO WS-DETAIL-COUNT
               END-IF
               
               IF REC-TYPE = 'T'
      * BUG 3: Just prints success without checking
                   DISPLAY "VALIDATION SUCCESSFUL"
               END-IF
               
               READ EFT-FILE AT END MOVE 'Y' TO WS-EOF
           END-PERFORM.

           CLOSE EFT-FILE.
           STOP RUN.
