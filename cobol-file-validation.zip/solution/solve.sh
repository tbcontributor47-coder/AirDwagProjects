#!/bin/bash
set -eu

cat <<EOF > validate.cbl
       IDENTIFICATION DIVISION.
       PROGRAM-ID. EFT-VALIDATOR.
       ENVIRONMENT DIVISION.
       INPUT-OUTPUT SECTION.
       FILE-CONTROL.
           SELECT EFT-FILE ASSIGN TO "eft_input.dat"
               ORGANIZATION IS LINE SEQUENTIAL.
       DATA DIVISION.
       FILE SECTION.
       FD EFT-FILE.
       01 EFT-REC.
           05 REC-TYPE         PIC X.
           05 REC-DATA         PIC X(79).

       WORKING-STORAGE SECTION.
       01 WS-EOF               PIC X VALUE 'N'.
       01 WS-DETAIL-COUNT      PIC 9(5) VALUE 0.
       01 WS-SUM-AMOUNT        PIC 9(13)V99 VALUE 0.
       
       01 DETAIL-REC.
           05 DET-TYPE         PIC X.
           05 DET-AMOUNT       PIC 9(8)V99.
           05 DET-ACCOUNT      PIC X(12).
           05 DET-CHKSUM       PIC 9(10).

       01 TRAILER-REC.
           05 TRL-TYPE         PIC X.
           05 TRL-TOTAL        PIC 9(13)V99.
           05 TRL-COUNT        PIC 9(5).

       01 WS-TEMP-SUM          PIC 9(10) VALUE 0.
       01 WS-IDX               PIC 99.
       01 WS-ACC-ARR.
           05 WS-ACC-CHAR      PIC X OCCURS 12 TIMES.

       PROCEDURE DIVISION.
           OPEN INPUT EFT-FILE.
           
           READ EFT-FILE AT END MOVE 'Y' TO WS-EOF.
           
           PERFORM UNTIL WS-EOF = 'Y'
               IF REC-TYPE = 'D'
                   MOVE EFT-REC TO DETAIL-REC
                   ADD 1 TO WS-DETAIL-COUNT
                   ADD DET-AMOUNT TO WS-SUM-AMOUNT
                   
                   * Checksum calculation
                   MOVE 0 TO WS-TEMP-SUM
                   MOVE DET-ACCOUNT TO WS-ACC-ARR
                   PERFORM VARYING WS-IDX FROM 1 BY 1 
                           UNTIL WS-IDX > 12
                       IF WS-ACC-CHAR(WS-IDX) NUMERIC
                           ADD FUNCTION NUMVAL(WS-ACC-CHAR(WS-IDX)) 
                               TO WS-TEMP-SUM
                       END-IF
                   END-PERFORM
                   
                   IF WS-TEMP-SUM NOT = DET-CHKSUM
                       DISPLAY "INVALID: CHECKSUM_ERR"
                       CLOSE EFT-FILE
                       STOP RUN
                   END-IF
               END-IF
               
               IF REC-TYPE = 'T'
                   MOVE EFT-REC TO TRAILER-REC
                   IF WS-DETAIL-COUNT NOT = TRL-COUNT
                       DISPLAY "INVALID: COUNT_MISMATCH"
                       CLOSE EFT-FILE
                       STOP RUN
                   END-IF
                   IF WS-SUM-AMOUNT NOT = TRL-TOTAL
                       DISPLAY "INVALID: SUM_MISMATCH"
                       CLOSE EFT-FILE
                       STOP RUN
                   END-IF
                   DISPLAY "VALID"
               END-IF
               
               READ EFT-FILE AT END MOVE 'Y' TO WS-EOF
           END-PERFORM.

           CLOSE EFT-FILE.
           STOP RUN.
EOF
# Fixed validate.cbl is already written to the current directory by the heredoc above
