# COBOL: Electronic Funds Transfer (EFT) Validation

Your task is to implement a robust validation program for EFT batch files.

## Input File Format (`eft_input.dat`)
The file is line-sequential with fixed-position fields. The first character determines the record type.

### Header (Type 'H')
- Pos 1: `H`
- Pos 2-9: Date (YYYYMMDD)
- Pos 10-14: Batch ID

### Detail (Type 'D')
- Pos 1: `D`
- Pos 2-11: Amount (`PIC 9(8)V99`)
- Pos 12-23: Account Number (`PIC X(12)`)
- Pos 24-33: Account Checksum (`PIC 9(10)`)

### Trailer (Type 'T')
- Pos 1: `T`
- Pos 2-16: Total Amount (`PIC 9(13)V99`)
- Pos 17-21: Total Count of Detail Records (`PIC 9(5)`)

## Requirements
1.  **Count Validation**: The number of 'D' records must match the trailer `TRL-COUNT`.
2.  **Sum Validation**: The sum of all 'D' record amounts must match trailer `TRL-TOTAL`.
3.  **Checksum Validation**: Each 'D' record has an `Account Checksum`. This checksum must equal the numeric sum of the 12 digits in the `Account Number`. If the account number contains non-numeric characters, treat their value as 0.
4.  **Error Reporting**:
    - If valid: Print `VALID` to stdout.
    - If invalid (any check fails): Print `INVALID: <REASON>` to stdout, where `<REASON>` is one of: `COUNT_MISMATCH`, `SUM_MISMATCH`, or `CHECKSUM_ERR`.
    - If multiple errors exist, report only the first one found in this priority order: COUNT > SUM > CHECKSUM.

## Task
Modify `/app/validate.cbl` to implement these validation rules correctly. 
- Ensure strict adherence to COBOL margin rules (Area A/B).
- Exit with code 0.
