#!/usr/bin/env python3

import argparse
import json
import sys
from typing import Any


def _dump_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _parse_args(argv: list[str]) -> argparse.Namespace:
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--expected", required=True)
    p.add_argument("--actual", required=True)
    p.add_argument("--tolerance", type=float, default=0.0)
    p.add_argument("--ignore", action="append", default=[])
    return p.parse_args(argv)


def _is_ignored(pointer: str, ignores: list[str]) -> bool:
    # BUG: only checks exact match, doesn't check if pointer is descendant of ignored path
    return pointer in ignores


def _first_diff(expected: Any, actual: Any, pointer: str, ignores: list[str], tolerance: float = 0.0) -> tuple[str, Any, Any] | None:
    if _is_ignored(pointer, ignores):
        return None

    # BUG: type check happens before bool/int special handling
    # This causes booleans to be treated differently than spec requires
    if type(expected) is not type(actual):
        return pointer, expected, actual

    if isinstance(expected, dict):
        exp_keys = sorted(expected.keys())
        act_keys = sorted(actual.keys())

        for k in exp_keys:
            # BUG: doesn't escape special characters in JSON Pointer (~ and /)
            child_ptr = pointer + "/" + str(k)
            if k not in actual:
                return child_ptr, expected[k], None
            d = _first_diff(expected[k], actual[k], child_ptr, ignores, tolerance)
            if d is not None:
                return d

        for k in act_keys:
            if k not in expected:
                child_ptr = pointer + "/" + str(k)
                return child_ptr, None, actual[k]

        return None

    if isinstance(expected, list):
        # BUG: all arrays order-sensitive; no special `/items` handling for multiset comparison
        n = min(len(expected), len(actual))
        for i in range(n):
            child_ptr = pointer + "/" + str(i)
            d = _first_diff(expected[i], actual[i], child_ptr, ignores, tolerance)
            if d is not None:
                return d
        if len(expected) != len(actual):
            child_ptr = pointer + "/" + str(n)
            exp_v = expected[n] if n < len(expected) else None
            act_v = actual[n] if n < len(actual) else None
            return child_ptr, exp_v, act_v
        return None

    # Handle strings
    if isinstance(expected, str) and isinstance(actual, str):
        # BUG: strips ALL whitespace instead of just trailing whitespace
        if expected.strip() != actual.strip():
            return pointer, expected, actual
        return None

    # Handle numbers with tolerance
    if isinstance(expected, (int, float)) and isinstance(actual, (int, float)):
        # BUG: uses < instead of <=, so exact tolerance boundary fails
        if abs(expected - actual) < tolerance:
            return None
        return pointer, expected, actual

    # Fallback for other types (bool, None, etc.)
    if expected != actual:
        return pointer, expected, actual

    return None


def main(argv: list[str]) -> int:
    try:
        args = _parse_args(argv)
    except SystemExit:
        print("Usage: python3 /app/compare_json.py --expected <path> --actual <path> [--tolerance <float>] [--ignore <json-pointer>]...", file=sys.stderr)
        return 1

    try:
        with open(args.expected, "r", encoding="utf-8") as f:
            expected = json.load(f)
        with open(args.actual, "r", encoding="utf-8") as f:
            actual = json.load(f)
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 1

    diff = _first_diff(expected, actual, "", args.ignore, args.tolerance)
    if diff is None:
        sys.stdout.write("EQUAL\n")
        return 0

    ptr, exp_v, act_v = diff
    if ptr == "":
        ptr = "/"

    sys.stdout.write("NOT_EQUAL\n")
    sys.stdout.write(f"FIRST_DIFF {ptr}\n")
    sys.stdout.write(f"EXPECTED {_dump_json(exp_v)}\n")
    sys.stdout.write(f"ACTUAL {_dump_json(act_v)}\n")
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
